<!-- <?php 
//if (isset($_POST['checking_view'])) {
    //echo "welcome";

//include 'config.php';

//$id=$_POST['id'];
//$array_result=[];
//$sql="SELECT * from users WHERE id=$id";
//$result=$conn->query($sql);

//return $result;
// foreach($result as $res){
//    array_push($array_result, $res);   
// }
//    header('Content_type: application/json');
//    echo json_encode($array_result);



}

 ?>
 -->
