<?php 
$serverName='localhost';
$userName="root";
$dbName="ajax";
$password="";

$conn=mysqli_connect($serverName,$userName,$password,$dbName);
//$con=new mysqli();

/*
if($conn){	
	echo "successfully db mysqli_connect";
}else {
	echo "Not successfully db mysqli_connect";
}
*/

 ?>

